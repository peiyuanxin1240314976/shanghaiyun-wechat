export default [
  {
    icon: 'home',
    text: '首页',
    url: 'pages/home/home',
  },
  {
    icon: 'sort',
    text: '发布群',
    url: 'pages/category/index',
  },
  {
    icon: 'discount',
    text: '推广',
    url: 'pages/promotion/index',
  },
  {
    icon: 'person',
    text: '个人中心',
    url: 'pages/usercenter/index',
  },
];
