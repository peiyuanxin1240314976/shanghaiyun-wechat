import { TdLinkProps } from './type';
declare const props: TdLinkProps;
export default props;
