import { TdIndexesAnchorProps } from './type';
declare const props: TdIndexesAnchorProps;
export default props;
