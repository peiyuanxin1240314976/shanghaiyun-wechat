export interface TdIndexesAnchorProps {
    index?: {
        type: null;
        value?: string | number;
    };
}
