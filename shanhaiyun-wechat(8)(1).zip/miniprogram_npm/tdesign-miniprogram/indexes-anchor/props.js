const props = {
    index: {
        type: null,
    },
};
export default props;
