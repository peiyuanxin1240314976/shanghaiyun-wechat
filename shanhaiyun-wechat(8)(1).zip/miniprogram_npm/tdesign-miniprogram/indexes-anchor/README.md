:: BASE_DOC ::

## API
### IndexesAnchor Props

名称 | 类型 | 默认值 | 说明 | 必传
-- | -- | -- | -- | --
index | String / Number | - | 索引字符 | N

### IndexesAnchor 外部样式类
类名 | 说明
-- | -- 
t-class | 根节点样式类