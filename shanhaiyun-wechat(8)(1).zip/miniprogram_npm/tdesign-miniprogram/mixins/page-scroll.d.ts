declare const _default: (funcName?: string) => string;
export default _default;
