declare const themeChangeBehavior: string;
export default themeChangeBehavior;
