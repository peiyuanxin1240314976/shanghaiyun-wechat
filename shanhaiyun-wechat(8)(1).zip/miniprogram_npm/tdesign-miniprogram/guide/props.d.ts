import { TdGuideProps } from './type';
declare const props: TdGuideProps;
export default props;
