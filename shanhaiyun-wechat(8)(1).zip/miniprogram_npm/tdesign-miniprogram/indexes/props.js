const props = {
    indexList: {
        type: null,
    },
    sticky: {
        type: Boolean,
        value: true,
    },
    stickyOffset: {
        type: Number,
        value: 0,
    },
};
export default props;
