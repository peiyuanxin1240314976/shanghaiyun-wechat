import { TdColorPickerProps } from './type';
declare const props: TdColorPickerProps;
export default props;
