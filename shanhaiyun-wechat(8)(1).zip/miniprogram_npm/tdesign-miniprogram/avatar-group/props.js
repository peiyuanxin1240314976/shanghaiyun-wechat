const props = {
    cascading: {
        type: String,
        value: 'left-up',
    },
    collapseAvatar: {
        type: String,
    },
    max: {
        type: Number,
    },
    shape: {
        type: String,
    },
    size: {
        type: String,
        value: '',
    },
};
export default props;
