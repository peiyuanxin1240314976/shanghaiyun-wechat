export declare function compareVersion(v1: any, v2: any): 0 | 1 | -1;
export declare function canIUseFormFieldButton(): boolean;
export declare function canUseVirtualHost(): boolean;
export declare function canUseProxyScrollView(): boolean;
