:: BASE_DOC ::

## API


### Icon Props

name | type | default | description | required
-- | -- | -- | -- | --
style | Object | - | CSS(Cascading Style Sheets) | N
custom-style | Object | - | CSS(Cascading Style Sheets)，used to set style on virtual component | N
color | String | - | \- | N
name | String | - | required | Y
prefix | String | - | \- | N
size | String / Number | - | \- | N

### Icon Events

name | params | description
-- | -- | --
click | \- | [see more ts definition](https://github.com/Tencent/tdesign-miniprogram/blob/develop/src/common/common.ts)
### Icon External Classes

className | Description
-- | --
t-class | \-
