const props = {
    color: {
        type: String,
        value: '',
    },
    name: {
        type: String,
        value: '',
        required: true,
    },
    prefix: {
        type: String,
        value: '',
    },
    size: {
        type: null,
    },
};
export default props;
