const props = {
    links: {
        type: Array,
        value: [],
    },
    logo: {
        type: Object,
    },
    text: {
        type: String,
        value: '',
    },
};
export default props;
