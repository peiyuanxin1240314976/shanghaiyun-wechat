import { TdDraggableProps } from './type';
declare const props: TdDraggableProps;
export default props;
