const props = {
    direction: {
        type: String,
        value: 'all',
    },
};
export default props;
