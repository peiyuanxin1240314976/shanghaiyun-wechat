const props = {
    bordered: {
        type: Boolean,
        value: false,
    },
    theme: {
        type: String,
        value: 'default',
    },
    title: {
        type: String,
        value: '',
    },
};
export default props;
