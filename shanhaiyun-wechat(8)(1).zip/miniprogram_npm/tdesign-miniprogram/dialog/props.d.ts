import { TdDialogProps } from './type';
declare const props: TdDialogProps;
export default props;
